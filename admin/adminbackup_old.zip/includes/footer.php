<div>

    <div class="footer">
        <div class="clearfix"> </div>
        <p style="font-family: cursive;"></p>
    </div>
</div>