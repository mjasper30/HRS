<div class="header-section">
    <!-- top_bg -->
    <div class="top_bg">

        <div class="header_top">
            <div class="top_right">
                <ul>
                    <li><a href="profile.php">Profile</a></li>|
                    <li><a href="change-password.php">Change Password</a></li>|
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>

            <div class="clearfix"> </div>
        </div>

    </div>
    <div class="clearfix"></div>
    <!-- /top_bg -->
</div>